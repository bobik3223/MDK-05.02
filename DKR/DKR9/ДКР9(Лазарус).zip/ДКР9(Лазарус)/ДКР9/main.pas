unit main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  Grids, Menus;

// Структура нашей записи (Посещение пациентов)
type
  TPatient = record
    CardNum: Integer;
    FIO: String[100];
    Diagnosis: String[100];
    VisitDate: String[20];
    Doctor: String[50];
  end;

type
  { TForm1 }
  TForm1 = class(TForm)
    edCard: TEdit;
    edFIO: TEdit;
    edDiag: TEdit;
    edDate: TEdit;
    edDoctor: TEdit;
    Grid: TStringGrid;
    Lbl1: TLabel;
    Lbl3: TLabel;
    Lbl2: TLabel;
    Lbl5: TLabel;
    Lbl4: TLabel;
    MainMenu1: TMainMenu;
    menuFile: TMenuItem;
    menuFileNew: TMenuItem;
    menuFileOpen: TMenuItem;
    menuFileSave: TMenuItem;
    menuFileSaveAs: TMenuItem;
    menuFileClose: TMenuItem;
    MenuItem1: TMenuItem;
    menuFileExit: TMenuItem;
    menuRecClear: TMenuItem;
    menuSearch: TMenuItem;
    menuSep3: TMenuItem;
    menuSortDesc: TMenuItem;
    menuSortAsc: TMenuItem;
    menuSortParent: TMenuItem;
    menuRecEdit: TMenuItem;
    menuRecDel: TMenuItem;
    menuSep2: TMenuItem;
    menuRecAdd: TMenuItem;
    menuRec: TMenuItem;
    OpenDialog1: TOpenDialog;
    PanelTop: TPanel;
    SaveDialog1: TSaveDialog;

    // Основные события
    procedure FormCreate(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean); // Проверка при закрытии
    procedure GridSelectCell(Sender: TObject; aCol, aRow: Integer; var CanSelect: Boolean); // Выбор в таблице

    // События меню
    procedure menuFileNewClick(Sender: TObject); // Создать
    procedure menuFileOpenClick(Sender: TObject); // Открыть
    procedure menuFileSaveClick(Sender: TObject); // Сохранить
    procedure menuFileSaveAsClick(Sender: TObject); // Сохранить как
    procedure menuFileCloseClick(Sender: TObject); // Закрыть файл
    procedure menuFileExitClick(Sender: TObject); // Выход
    procedure menuRecAddClick(Sender: TObject); // Добавить
    procedure menuRecEditClick(Sender: TObject); // Редактировать
    procedure menuRecDelClick(Sender: TObject); // Удалить
    procedure menuSortAscClick(Sender: TObject); // Сортировка по возрастанию
    procedure menuSortDescClick(Sender: TObject); // Сортировка по убыванию
    procedure menuSearchClick(Sender: TObject); // Поиск
    procedure menuRecClearClick(Sender: TObject); // Очистить форму

    // Случайные пустые клики (оставляем, чтобы Лазарус не выдавал ошибку)
    procedure Lbl1Click(Sender: TObject);
    procedure Lbl2Click(Sender: TObject);
    procedure menuFileClick(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure menuSortParentClick(Sender: TObject);
    procedure PanelTopClick(Sender: TObject);

  private
    CurrentFile: string;
    IsModified: Boolean;

    procedure SetupGrid;
    procedure ClearInputs;
    procedure LoadFromFile(FileName: string);
    procedure SaveToFile(FileName: string; ShowMsg: Boolean = True);
    procedure AutoSave;
    procedure SortGrid(Ascending: Boolean);
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

// === НАСТРОЙКИ ПРИ ЗАПУСКЕ ===

procedure TForm1.SetupGrid;
begin
  Grid.Cells[0, 0] := '№ Карты';
  Grid.Cells[1, 0] := 'ФИО Пациента';
  Grid.Cells[2, 0] := 'Диагноз';
  Grid.Cells[3, 0] := 'Дата приема';
  Grid.Cells[4, 0] := 'Врач';
  Grid.ColWidths[0] := 80; Grid.ColWidths[1] := 200; Grid.ColWidths[2] := 180;
  Grid.ColWidths[3] := 100; Grid.ColWidths[4] := 150;
  Grid.RowCount := 1;
end;

procedure TForm1.ClearInputs;
begin
  edCard.Clear; edFIO.Clear; edDiag.Clear; edDate.Clear; edDoctor.Clear;
  edCard.SetFocus;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  SetupGrid;
  CurrentFile := '';
  IsModified := False;
end;

// Защита от случайного закрытия программы с несохраненными данными
procedure TForm1.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if IsModified then
  begin
    if MessageDlg('Внимание', 'Есть несохраненные изменения! Сохранить перед выходом?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      menuFileSaveClick(Sender);
  end;
  CanClose := True;
end;

// При клике на строку в таблице - переносим данные в поля ввода
procedure TForm1.GridSelectCell(Sender: TObject; aCol, aRow: Integer; var CanSelect: Boolean);
begin
  if (aRow > 0) and (aRow < Grid.RowCount) then
  begin
    edCard.Text := Grid.Cells[0, aRow];
    edFIO.Text := Grid.Cells[1, aRow];
    edDiag.Text := Grid.Cells[2, aRow];
    edDate.Text := Grid.Cells[3, aRow];
    edDoctor.Text := Grid.Cells[4, aRow];
  end;
end;

// === РАБОТА С ТИПИЗИРОВАННЫМИ ФАЙЛАМИ ===

procedure TForm1.LoadFromFile(FileName: string);
var
  F: file of TPatient;
  Rec: TPatient;
  R: Integer;
begin
  try
    AssignFile(F, FileName);
    Reset(F);

    Grid.RowCount := 1;
    R := 1;

    while not Eof(F) do
    begin
      Read(F, Rec);
      Grid.RowCount := R + 1;
      Grid.Cells[0, R] := IntToStr(Rec.CardNum);
      Grid.Cells[1, R] := Rec.FIO;
      Grid.Cells[2, R] := Rec.Diagnosis;
      Grid.Cells[3, R] := Rec.VisitDate;
      Grid.Cells[4, R] := Rec.Doctor;
      Inc(R);
    end;

    CurrentFile := FileName;
    IsModified := False;
    Form1.Caption := 'Учет посещений - ' + ExtractFileName(FileName);
  finally
    CloseFile(F);
  end;
end;

procedure TForm1.SaveToFile(FileName: string; ShowMsg: Boolean = True);
var
  F: file of TPatient;
  Rec: TPatient;
  R: Integer;
begin
  try
    AssignFile(F, FileName);
    Rewrite(F);

    for R := 1 to Grid.RowCount - 1 do
    begin
      Rec.CardNum := StrToIntDef(Grid.Cells[0, R], 0);
      Rec.FIO := Grid.Cells[1, R];
      Rec.Diagnosis := Grid.Cells[2, R];
      Rec.VisitDate := Grid.Cells[3, R];
      Rec.Doctor := Grid.Cells[4, R];
      Write(F, Rec);
    end;

    CurrentFile := FileName;
    IsModified := False;
    if ShowMsg then ShowMessage('Данные сохранены!');
  except
    ShowMessage('Ошибка записи! Проверьте права доступа к файлу.');
  end;
end;

procedure TForm1.AutoSave;
begin
  if CurrentFile <> '' then
    SaveToFile(CurrentFile, False)
  else
    IsModified := True;
end;

// === МЕНЮ: ФАЙЛ ===

procedure TForm1.menuFileNewClick(Sender: TObject);
begin
  if IsModified then menuFileCloseClick(Sender);
  Grid.RowCount := 1;
  ClearInputs;
  CurrentFile := '';
  IsModified := False;
  Form1.Caption := 'Учет посещений - Новый файл';
end;

procedure TForm1.menuFileOpenClick(Sender: TObject);
begin
  if OpenDialog1.Execute then
  begin
    try
      LoadFromFile(OpenDialog1.FileName);
    except
      ShowMessage('Ошибка! Невозможно открыть файл или неверный формат.');
    end;
  end;
end;

procedure TForm1.menuFileSaveClick(Sender: TObject);
begin
  if CurrentFile = '' then
    menuFileSaveAsClick(Sender)
  else
    SaveToFile(CurrentFile);
end;

procedure TForm1.menuFileSaveAsClick(Sender: TObject);
begin
  if SaveDialog1.Execute then SaveToFile(SaveDialog1.FileName);
end;

procedure TForm1.menuFileCloseClick(Sender: TObject);
begin
  if IsModified then
    if MessageDlg('Сохранить изменения перед закрытием?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      menuFileSaveClick(Sender);

  Grid.RowCount := 1;
  CurrentFile := '';
  IsModified := False;
  ClearInputs;
  Form1.Caption := 'Учет посещений пациентов';
end;

procedure TForm1.menuFileExitClick(Sender: TObject);
begin
  Close;
end;

// === МЕНЮ: ЗАПИСЬ ===

procedure TForm1.menuRecClearClick(Sender: TObject);
begin
  ClearInputs;
end;

procedure TForm1.menuRecAddClick(Sender: TObject);
var
  Card: Integer;
  sFIO, sDiag, sDate, sDoc: String; // 1. Создаем переменные-хранилища
begin
  if (edCard.Text='') or (edFIO.Text='') or (edDiag.Text='') then
  begin
    ShowMessage('Ошибка! Заполните Номер карты, ФИО и Диагноз.');
    Exit;
  end;

  try
    Card := StrToInt(edCard.Text);
  except
    ShowMessage('Ошибка! Номер карты должен содержать только цифры.');
    Exit;
  end;

  // 2. СОХРАНЯЕМ весь введенный текст в память ДО изменения таблицы
  sFIO := edFIO.Text;
  sDiag := edDiag.Text;
  sDate := edDate.Text;
  sDoc := edDoctor.Text;

  // 3. Создаем новую строку (тут сработает ловушка и поля очистятся, но данные уже в безопасности!)
  Grid.RowCount := Grid.RowCount + 1;

  // 4. Записываем данные из безопасных переменных в таблицу
  Grid.Cells[0, Grid.RowCount - 1] := IntToStr(Card);
  Grid.Cells[1, Grid.RowCount - 1] := sFIO;
  Grid.Cells[2, Grid.RowCount - 1] := sDiag;
  Grid.Cells[3, Grid.RowCount - 1] := sDate;
  Grid.Cells[4, Grid.RowCount - 1] := sDoc;

  ClearInputs;
  AutoSave;
end;

procedure TForm1.menuRecEditClick(Sender: TObject);
var R, Card: Integer;
begin
  R := Grid.Row;
  if (R < 1) or (Grid.RowCount = 1) then
  begin
    ShowMessage('Выберите запись в таблице для редактирования!');
    Exit;
  end;

  // НОВАЯ ЗАЩИТА: Не даем стереть данные пустыми полями!
  if (edCard.Text='') or (edFIO.Text='') or (edDiag.Text='') then
  begin
    ShowMessage('Ошибка! Заполните Номер карты, ФИО и Диагноз перед сохранением изменений.');
    Exit;
  end;

  try
    Card := StrToInt(edCard.Text);
  except
    ShowMessage('Ошибка! Номер карты должен быть числом.');
    Exit;
  end;

  Grid.Cells[0, R] := IntToStr(Card);
  Grid.Cells[1, R] := edFIO.Text;
  Grid.Cells[2, R] := edDiag.Text;
  Grid.Cells[3, R] := edDate.Text;
  Grid.Cells[4, R] := edDoctor.Text;

  ClearInputs;
  AutoSave;
end;

procedure TForm1.menuRecDelClick(Sender: TObject);
var R: Integer;
begin
  R := Grid.Row;
  if (R < 1) or (Grid.RowCount = 1) then
  begin
    ShowMessage('Сначала выделите строку для удаления!');
    Exit;
  end;

  if MessageDlg('Удаление', 'Удалить пациента?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    Grid.DeleteRow(R);
    ClearInputs;
    AutoSave;
  end;
end;

// === ПОИСК И СОРТИРОВКА ===

procedure TForm1.menuSearchClick(Sender: TObject);
var
  SearchStr: string;
  R: Integer;
  Found: Boolean;
begin
  SearchStr := InputBox('Поиск', 'Введите ФИО или Диагноз для поиска:', '');
  if SearchStr = '' then Exit;

  Found := False;
  for R := 1 to Grid.RowCount - 1 do
  begin
    if (Pos(AnsiLowerCase(SearchStr), AnsiLowerCase(Grid.Cells[1, R])) > 0) or
       (Pos(AnsiLowerCase(SearchStr), AnsiLowerCase(Grid.Cells[2, R])) > 0) then
    begin
      Grid.Row := R;
      GridSelectCell(Self, 1, R, Found);
      ShowMessage('Запись найдена!');
      Found := True;
      Break;
    end;
  end;
  if not Found then ShowMessage('Совпадений не найдено.');
end;

procedure TForm1.SortGrid(Ascending: Boolean);
var
  i, j, ColIdx, c: Integer;
  v1, v2, temp: string;
  n1, n2: Integer;
  Swap: Boolean;
begin
  if Grid.RowCount < 3 then Exit;
  ColIdx := Grid.Col;

  for i := 1 to Grid.RowCount - 2 do
    for j := i + 1 to Grid.RowCount - 1 do
    begin
      v1 := Grid.Cells[ColIdx, i];
      v2 := Grid.Cells[ColIdx, j];
      Swap := False;

      if ColIdx = 0 then
      begin
        n1 := StrToIntDef(v1, 0);
        n2 := StrToIntDef(v2, 0);
        if Ascending then Swap := n1 > n2 else Swap := n1 < n2;
      end
      else
      begin
        if Ascending then Swap := AnsiCompareText(v1, v2) > 0
        else Swap := AnsiCompareText(v1, v2) < 0;
      end;

      if Swap then
      begin
         for c := 0 to Grid.ColCount - 1 do
         begin
           temp := Grid.Cells[c, i];
           Grid.Cells[c, i] := Grid.Cells[c, j];
           Grid.Cells[c, j] := temp;
         end;
      end;
    end;
  AutoSave;
end;

procedure TForm1.menuSortAscClick(Sender: TObject);
begin
  SortGrid(True);
end;

procedure TForm1.menuSortDescClick(Sender: TObject);
begin
  SortGrid(False);
end;

// === ПУСТЫЕ КЛИКИ (Оставляем для совместимости формы) ===
procedure TForm1.Lbl1Click(Sender: TObject); begin end;
procedure TForm1.Lbl2Click(Sender: TObject); begin end;
procedure TForm1.menuFileClick(Sender: TObject); begin end;
procedure TForm1.MenuItem2Click(Sender: TObject); begin end;
procedure TForm1.menuSortParentClick(Sender: TObject); begin end;
procedure TForm1.PanelTopClick(Sender: TObject); begin end;

end.
