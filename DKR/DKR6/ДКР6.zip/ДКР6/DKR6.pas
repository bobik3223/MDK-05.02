﻿uses crt;
const MAX_SIZE = 5; 
type // структура элемента списка
  TypeEl = record
    Data: integer;
    Next: integer; 
    Prev: integer; 
    Used: boolean; // занята ли ячейка массива
  end;

var List: array[1..MAX_SIZE] of TypeEl;
  Head: integer;   
  Count: integer;  
  Choice: integer; 
  InputVal: integer;

procedure InitList;
var i: integer;
begin
  for i := 1 to MAX_SIZE do
    List[i].Used := false; // типо все свободные
  Head := 0; 
  Count := 0;
end;

function GetFreeIndex: integer;
var i: integer;
begin
  for i := 1 to MAX_SIZE do
    if not List[i].Used then exit(i); // индекс свободной ячейки
  GetFreeIndex := 0;
end;

procedure AddElement(Val: integer);
var NewIdx, Last: integer;
begin
  NewIdx := GetFreeIndex;
  if NewIdx = 0 then begin writeln('Недостаточно памяти'); exit; end;

  List[NewIdx].Data := Val; // запись данных
  List[NewIdx].Used := true; // занятая ячейка

  if Head = 0 then
  begin
    Head := NewIdx;
    List[NewIdx].Next := NewIdx; // ссылается сам на себя, т.е замыкаем кольцо
    List[NewIdx].Prev := NewIdx; 
  end
  else
  begin
    Last := List[Head].Prev; // вставка в конец кольца
    
    List[Last].Next := NewIdx; // старый хвост - новый
    List[NewIdx].Prev := Last; // новый - старый хвост 
    List[NewIdx].Next := Head; // новый - голова (кольцо)
    List[Head].Prev := NewIdx; // голова - новый
  end;
  inc(Count);
  writeln('Элемент добавлен в ячейку ', NewIdx);
end;

procedure DeleteElement(Val: integer);
var Current, i: integer;
  Found: boolean;
begin
  Current := Head;
  Found := false;
  
  // перебираем элементы по цепочке Next
  for i := 1 to Count do
  begin
    if List[Current].Data = Val then begin Found := true; break; end;
    Current := List[Current].Next;
  end;

  if Found then
  begin
    if Count = 1 then Head := 0 // если был один, список стал пустым
    else
    begin
      // сосед слева теперь смотрит на соседа справа
      List[List[Current].Prev].Next := List[Current].Next;
      // сосед справа теперь смотрит на соседа слева
      List[List[Current].Next].Prev := List[Current].Prev;
      if Current = Head then Head := List[Current].Next; // двигаем голову если удалили
    end;
    List[Current].Used := false; // освобождение ячейки
    dec(Count);
    writeln('Элемент ', Val, ' удален');
  end
  else
    writeln('Элемент не найден.');
end;

procedure Visual;
var Current, i: integer;
begin
  if Head = 0 then begin writeln('Список пуст'); exit; end;

  writeln(#10'--- Визуализация ---');
  writeln('Индекс головы: ', Head);
  writeln('ID | Data | Next | Prev');
  writeln('-----------------------');
  
  Current := Head;
  for i := 1 to Count do
  begin
    writeln(Current:2, ' | ', List[Current].Data:4 , ' | ', List[Current].Next:4, ' | ', List[Current].Prev:4);
    Current := List[Current].Next;
  end;
  writeln('-----------------------');
end;

begin // основа
  InitList;
  repeat
    writeln('МЕНЮ УПРАВЛЕНИЯ:');
    writeln('1. Добавить элемент');
    writeln('2. Удалить элемент');
    writeln('3. Вывести визуализацию');
    writeln('0. Выход');
    write('Выбор действия: ');
    readln(Choice);

    case Choice of
      1: begin
           write('Введите число: ');
           readln(InputVal);
           AddElement(InputVal);
         end;
      2: begin
           write('Введите число для удаления: ');
           readln(InputVal);
           DeleteElement(InputVal);
         end;
      3: Visual;
      0: writeln('Завершение работы');
    else
      writeln('Выберите правильную цифру');
    end;
  until Choice = 0;
end.