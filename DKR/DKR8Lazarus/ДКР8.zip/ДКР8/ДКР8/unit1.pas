unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    btnCalc: TButton;
    cbShape: TComboBox;
    edtParam1: TEdit;
    edtParam2: TEdit;
    lblResult: TLabel;
    lblParam1: TLabel;
    lblParam2: TLabel;
    memHistory: TMemo;
    textChoice: TLabel;
    procedure btnCalcClick(Sender: TObject);
    procedure cbShapeChange(Sender: TObject);
    procedure edtParam1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

// В данном приложении используется 5 различных компонентов:
// 1. TLabel (Метки) - используются для вывода текстовых подсказок пользователю
//    и вывода итогового результата
// 2. TEdit (Текстовые поля) - используются для ввода числовых параметров
//    фигур пользователем
// 3. TComboBox (Выпадающий список) - используется для выбора типа
//    геометрической фигуры из фиксированного набора
// 4. TButton (Кнопка) - запускает процесс расчета площади
// 5. TMemo (Многострочное текстовое поле) - используется для Истории вычислений

procedure TForm1.FormCreate(Sender: TObject);
begin
    cbShapeChange(Sender);
end;


procedure TForm1.cbShapeChange(Sender: TObject);
begin
  edtParam1.Text := '';
  edtParam2.Text := '';

  case cbShape.ItemIndex of
    0: // Квадрат
      begin
        lblParam1.Caption := 'Сторона a:';
        lblParam2.Visible := False;
        edtParam2.Visible := False;
      end;
    1: // Прямоугольник
      begin
        lblParam1.Caption := 'Введите сторону a:';
        lblParam2.Caption := 'Введите сторону b:';
        lblParam2.Visible := True;
        edtParam2.Visible := True;
      end;
    2: // Круг
      begin
        lblParam1.Caption := 'Введите радиус:';
        lblParam2.Visible := False;
        edtParam2.Visible := False;
      end;
    3: // Треугольник
      begin
        lblParam1.Caption := 'Введите основание:';
        lblParam2.Caption := 'Введите высоту:';
        lblParam2.Visible := True;
        edtParam2.Visible := True;
      end;
  end;

end;

procedure TForm1.btnCalcClick(Sender: TObject);
var param1, param2, area: Double;
  ShapeName, HistLine: String;
begin
  try
    param1 := StrToFloat(edtParam1.Text);

    if param1 <= 0 then
    begin
      ShowMessage('Ошибка! Значение должно быть строго больше нуля');
      Exit;
    end;

    if param1 > 1E150 then
    begin
      ShowMessage('Ошибка! Введено слишком большое число.');
      Exit;
    end;

    if edtParam2.Visible = True then
    begin
      param2 := StrToFloat(edtParam2.Text);
      if param2 <= 0 then
      begin
        ShowMessage('Ошибка! Второе значение также должно быть больше нуля.');
        Exit;
      end;
      if param2 > 1E150 then
      begin
        ShowMessage('Ошибка! Второе число слишком большое.');
        Exit;
      end;
    end
    else
      param2 := 0;

    // Считаем площадь
    case cbShape.ItemIndex of
      0: begin
          area := Sqr(param1);
          ShapeName := 'Квадрат';
        end;
      1: begin
          area := param1 * param2;
          ShapeName := 'Прямоугольник';
        end;
      2: begin
          area := Pi * Sqr(param1);
          ShapeName := 'Круг';
        end;
      3: begin
          area := 0.5 * param1 * param2;
          ShapeName := 'Треугольник';
        end;
    end;

    lblResult.Caption := 'Площадь: ' + FloatToStrF(area, ffGeneral, 10, 2);

    if edtParam2.Visible then
      HistLine := 'Площадь (' + ShapeName + '): ' + FloatToStrF(area, ffGeneral, 10, 2) +
                  '  [Параметры: ' + FloatToStrF(param1, ffGeneral, 10, 2) + ' и ' + FloatToStrF(param2, ffGeneral, 10, 2) + ']'
    else
      HistLine := 'Площадь (' + ShapeName + '): ' + FloatToStrF(area, ffGeneral, 10, 2) +
                  '  [Параметр: ' + FloatToStrF(param1, ffGeneral, 10, 2) + ']';

    memHistory.Lines.Add(HistLine);

  except
    ShowMessage('Ошибка ввода! Пожалуйста, введите корректные числа');
  end;
end;


procedure TForm1.edtParam1Change(Sender: TObject);
begin

end;


end.

