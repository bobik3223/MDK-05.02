unit Unit2;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm2 }

  TForm2 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private

  public

  end;

var
  Form2: TForm2;

implementation

{$R *.lfm}

{ TForm2 }

// В равнобедренном треугольнике известно основание c,
// угол при основании равен alpha. Найти площадь треугольника S
// и величину боковой стороны a.

procedure TForm2.Button1Click(Sender: TObject);
var c, alpha, rad, a, S: Double;
begin
  c := StrToFloat(Edit1.Text);
  alpha := StrToFloat(Edit2.Text);

  rad := alpha * pi / 180;
  a := c / (2 * cos(rad));
  S := (sqr(c) * tan(rad)) / 4;

  Edit3.Text := FloatToStrF(a, ffFixed, 8, 2);
  Edit4.Text := FloatToStrF(S, ffFixed, 8, 2);
end;

procedure TForm2.Button2Click(Sender: TObject);
begin
  Edit1.Clear;
  Edit2.Clear;
  Edit3.Clear;
  Edit4.Clear;
  Edit1.SetFocus;
end;

end.

