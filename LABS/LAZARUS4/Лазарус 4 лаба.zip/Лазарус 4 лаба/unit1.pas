unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TformCalc }

  TformCalc = class(TForm)
    btn0: TButton;
    btn1: TButton;
    btnBack: TButton;
    btnEqual: TButton;
    btnC: TButton;
    btnCE: TButton;
    btnFract: TButton;
    btnDot: TButton;
    btnMult: TButton;
    btnDiv: TButton;
    btnSqr: TButton;
    btnPlus: TButton;
    btn2: TButton;
    btn3: TButton;
    btn4: TButton;
    btn5: TButton;
    btn6: TButton;
    btn7: TButton;
    btn8: TButton;
    btn9: TButton;
    btnMinus: TButton;
    btnSqrt: TButton;
    editDisplay: TEdit;
    procedure btn0Click(Sender: TObject);
    procedure btn1Click(Sender: TObject);
    procedure btn2Click(Sender: TObject);
    procedure btn3Click(Sender: TObject);
    procedure btn4Click(Sender: TObject);
    procedure btn5Click(Sender: TObject);
    procedure btn6Click(Sender: TObject);
    procedure btn7Click(Sender: TObject);
    procedure btn8Click(Sender: TObject);
    procedure btn9Click(Sender: TObject);
    procedure btnBackClick(Sender: TObject);
    procedure btnCClick(Sender: TObject);
    procedure btnCEClick(Sender: TObject);
    procedure btnDivClick(Sender: TObject);
    procedure btnDotClick(Sender: TObject);
    procedure btnEqualClick(Sender: TObject);
    procedure btnFractClick(Sender: TObject);
    procedure btnMinusClick(Sender: TObject);
    procedure btnMultClick(Sender: TObject);
    procedure btnPlusClick(Sender: TObject);
    procedure btnSqrClick(Sender: TObject);
    procedure btnSqrtClick(Sender: TObject);
    procedure editDisplayChange(Sender: TObject);
  private

  public

  end;

var
  formCalc: TformCalc;
  FirstNum: Real;
  Operation: Char;
  IsNewNum: Boolean;   // Флаг, нужно ли новое число

implementation

{$R *.lfm}

{ TformCalc }

procedure TformCalc.editDisplayChange(Sender: TObject);
begin

end;

// Процедура ввода цифры 2
procedure TformCalc.btn2Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '2';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '2';
    end;
end;

procedure TformCalc.btn3Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '3';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '3';
    end;
end;

procedure TformCalc.btn4Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '4';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '4';
    end;
end;

procedure TformCalc.btn5Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '5';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '5';
    end;
end;

procedure TformCalc.btn6Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '6';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '6';
    end;
end;

procedure TformCalc.btn7Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '7';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '7';
    end;
end;

procedure TformCalc.btn8Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '8';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '8';
    end;
end;

procedure TformCalc.btn9Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '9';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '9';
    end;
end;

procedure TformCalc.btnBackClick(Sender: TObject);
var S:string;
begin
  S := editDisplay.Text;

    if Pos('E', S) > 0 then
    begin
      ShowMessage('Предупреждение: число в научном формате. Нажмите "С" для полного сброса.');
      Exit;
    end;

    if Length(S) > 1 then
      Delete(S, Length(S), 1)
    else
      S := '0';

    editDisplay.Text := S;
end;

procedure TformCalc.btnCClick(Sender: TObject);
begin
  editDisplay.Text := '0';
  FirstNum := 0;
  Operation := ' ';
  IsNewNum := True;
end;

procedure TformCalc.btnCEClick(Sender: TObject);
begin
  editDisplay.Text := '0';
  IsNewNum := True;
end;

procedure TformCalc.btnDivClick(Sender: TObject);
begin
  try
      FirstNum := StrToFloat(editDisplay.Text);

      if Abs(FirstNum) > 1E150 then
      begin
        ShowMessage('Предупреждение: число слишком большое для дальнейших операций!');
        IsNewNum := True;
        Exit;
      end;

      Operation := '/';
      IsNewNum := True;
    except
      ShowMessage('Ошибка формата числа.');
      editDisplay.Text := '0';
      IsNewNum := True;
    end;
end;

procedure TformCalc.btn1Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '1';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '1';
    end;
end;

procedure TformCalc.btn0Click(Sender: TObject);
begin
  if (editDisplay.Text = '0') or (IsNewNum = True) then
    begin
      editDisplay.Text := '0';
      IsNewNum := False;
    end
    else
    begin
      if Length(editDisplay.Text) >= 15 then
      begin
        ShowMessage('Предупреждение: достигнут лимит ручного ввода!');
        Exit;
      end;

      editDisplay.Text := editDisplay.Text + '0';
    end;
end;

// Процедура добавления десятичной запятой
procedure TformCalc.btnDotClick(Sender: TObject);
begin
    if (Length(editDisplay.Text) >= 15) or (Pos('E', editDisplay.Text) > 0) then Exit;

    if Pos(',', editDisplay.Text) = 0 then
      editDisplay.Text := editDisplay.Text + ',';
    IsNewNum := False;
end;

// Процедура вычисления итогового результата
procedure TformCalc.btnEqualClick(Sender: TObject);
  var
  SecondNum: Real;
begin
    if Operation = ' ' then Exit;

      try
        SecondNum := StrToFloat(editDisplay.Text);

        // === ГЛОБАЛЬНАЯ ТАМОЖНЯ ОТ ПЕРЕПОЛНЕНИЯ ===
        if (Abs(FirstNum) > 1E150) or (Abs(SecondNum) > 1E150) then
        begin
          ShowMessage('Предупреждение: числа слишком огромные для вычислений!');
          Operation := ' ';
          IsNewNum := True;
          Exit; // Прерываем работу, ошибка не вылетит!
        end;
        // ==========================================

        case Operation of
          '+': editDisplay.Text := FloatToStr(FirstNum + SecondNum);
          '-': editDisplay.Text := FloatToStr(FirstNum - SecondNum);
          '*': editDisplay.Text := FloatToStr(FirstNum * SecondNum);
          '/':
            begin
              if SecondNum = 0 then
                ShowMessage('Ошибка, деление на ноль невозможно')
              else
                editDisplay.Text := FloatToStr(FirstNum / SecondNum);
            end;
        end;
      except
        ShowMessage('Ошибка! Сбой при вычислении.');
        editDisplay.Text := '0';
      end;

      IsNewNum := True;
      Operation := ' ';
end;

procedure TformCalc.btnFractClick(Sender: TObject);
  var Num: Real;
begin
  try
      Num := StrToFloat(editDisplay.Text);
      if Num = 0 then
        ShowMessage('Ошибка, деление на ноль невозможно')
      else
        editDisplay.Text := FloatToStr(1 / Num);
    except
      ShowMessage('Сбой при вычислении дроби.');
      editDisplay.Text := '0';
    end;
    IsNewNum := True;
end;

// Процедура операции вычитания
procedure TformCalc.btnMinusClick(Sender: TObject);
begin
  try
      FirstNum := StrToFloat(editDisplay.Text);

      if Abs(FirstNum) > 1E150 then
      begin
        ShowMessage('Предупреждение: превышен лимит для дальнейших операций!');
        IsNewNum := True;
        Exit;
      end;

      Operation := '-';
      IsNewNum := True;
    except
      ShowMessage('Ошибка формата числа.');
      editDisplay.Text := '0';
      IsNewNum := True;
    end;
end;

procedure TformCalc.btnMultClick(Sender: TObject);
begin
  try
      FirstNum := StrToFloat(editDisplay.Text);

      if Abs(FirstNum) > 1E150 then
      begin
        ShowMessage('Предупреждение: число слишком большое для дальнейших операций!');
        IsNewNum := True;
        Exit;
      end;

      Operation := '*';
      IsNewNum := True;
    except
      ShowMessage('Ошибка формата числа.');
      editDisplay.Text := '0';
      IsNewNum := True;
    end;
end;

// Процедура операции сложения
procedure TformCalc.btnPlusClick(Sender: TObject);
begin
  try
      FirstNum := StrToFloat(editDisplay.Text);

      if Abs(FirstNum) > 1E150 then
      begin
        ShowMessage('Предупреждение: число слишком большое для дальнейших операций!');
        IsNewNum := True;
        Exit;
      end;

      Operation := '+';
      IsNewNum := True;
    except
      ShowMessage('Ошибка формата числа.');
      editDisplay.Text := '0';
      IsNewNum := True;
    end;
end;

procedure TformCalc.btnSqrClick(Sender: TObject);
var Num: Real;
begin
  Num := StrToFloat(editDisplay.Text);

    // ЗАЩИТА: Если число больше 10 в 150-й степени, его квадрат вызовет крах
    if Abs(Num) > 1E150 then
    begin
      ShowMessage('Предупреждение: результат вычисления будет слишком огромным!');
      IsNewNum := True;
      Exit; // Отменяем возведение в квадрат
    end;

    editDisplay.Text := FloatToStr(Sqr(Num));
    IsNewNum := True;
end;

procedure TformCalc.btnSqrtClick(Sender: TObject);
var Num: Real;
begin
  Num := StrToFloat(editDisplay.Text);
  if Num < 0 then
    ShowMessage('Ошибка, корень из отрицательного числа')
  else
    editDisplay.Text := FloatToStr(Sqrt(Num));
  IsNewNum := True;
end;

end.

