unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type

  { TfMain }

  TfMain = class(TForm)
    lClock: TLabel;
    Timer1: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.FormCreate(Sender: TObject);
begin

end;

procedure TfMain.Timer1Timer(Sender: TObject);
var i:byte;
begin
    // Обновляем надпись метки на текущее время
    lClock.Caption := TimeToStr(Now);

    // Получаем случайное направление (от 0 до 3)
    i := Random(4);

    // Двигаем метку в зависимости от выпавшего числа
    case i of
      0: lClock.Left := lClock.Left + 50; // вправо
      1: lClock.Left := lClock.Left - 50; // влево
      2: lClock.Top := lClock.Top + 50;   // вверх
      3: lClock.Top := lClock.Top - 50;   // вниз
    end;

    // Проверяем: не улетела ли метка за края экрана?
    if lClock.Left < 0 then lClock.Left := 0;
    // если вверх
    if lClock.Top < 0 then lClock.Top := 0;
    //если вправо
    if (lClock.Left + lClock.Width) > fMain.Width then
      lClock.Left := fMain.Width - lClock.Width;
    // если вниз
    if (lClock.Top + lClock.Height) > fMain.Height then
      lClock.Top := fMain.Height - lClock.Height; [cite: 116]
end;

end.

