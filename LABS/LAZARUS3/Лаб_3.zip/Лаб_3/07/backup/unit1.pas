unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Calendar, EditBtn,
  StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Calendar1: TCalendar;
    DateEdit1: TDateEdit;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }



procedure TForm1.Button1Click(Sender: TObject);
begin
  ShowMessage(DateTimeToStr(Now));
end;

procedure TForm1.Button2Click(Sender: TObject);
var
 s: String;
begin
 case DayOfWeek(Now) of
 1: s:= 'Воскресение';
 2: s:= 'Понедельник';
 3: s:= 'Вторник';
 4: s:= 'Среда';
 5: s:= 'Четверг';
 6: s:= 'Пятница';
 7: s:= 'Суббота';
 end;
 ShowMessage('Сегодня ' + FormatDateTime('ddddd', Now) + ', ' + s);
end;

procedure TForm1.Button3Click(Sender: TObject);
  var
 Year, Month, Day: Word;
 s: String;
begin
 DecodeDate(Now, Year, Month, Day);
 ShowMessage('Год - ' + IntToStr(Year) + #13 +
 'Месяц - ' + IntToStr(Month) + #13 +
 'День - ' + IntToStr(Day));
end;

procedure TForm1.Button4Click(Sender: TObject);
  var
 Year, Month, Day: Word; //для указания года, месяца и дня
 dt: TDateTime; //для получения даты
 s: String;
begin
 //указываем год, число и день:
 Year:= 1999;
 Month:= 3;
 Day:= 9;
 //получаем дату:
 dt:= EncodeDate(Year, Month, Day);
 //теперь выводим ее:
 //ShowMessage('Указали ' + SysToUTF8(FormatDateTime('dddddd', dt)));
end;

procedure TForm1.Button5Click(Sender: TObject);
  var
 Year: Word;
begin
 Year:= 1917;
 //високосный или нет?
 if IsLeapYear(Year) then ShowMessage('Указан високосный год')
 else ShowMessage('Указан невисокосный год');
end;

procedure TForm1.Button6Click(Sender: TObject);
  var
 dt: TDateTime;
begin
 dt:= StrToDateTime('21.10.2013 14:25:30');
 ShowMessage('Указали ' + FormatDateTime('c', dt));
end;



end.

