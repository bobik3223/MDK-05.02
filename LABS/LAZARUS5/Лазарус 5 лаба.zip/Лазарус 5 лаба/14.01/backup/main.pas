unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TfMain }

  TfMain = class(TForm)
    bsave: TButton;
    bread: TButton;
    bclear: TButton;
    Memo1: TMemo;
    procedure bclearClick(Sender: TObject);
    procedure breadClick(Sender: TObject);
    procedure bsaveClick(Sender: TObject);
  private

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.bsaveClick(Sender: TObject);
begin
  Memo1.Lines.SaveToFile('MyText.txt');
end;

procedure TfMain.breadClick(Sender: TObject);
begin
  if FileExists('MyText.txt') then
    Memo1.Lines.LoadFromFile('MyText.txt')
  else ShowMessage('Файл MyText.txt не существует');
end;

procedure TfMain.bclearClick(Sender: TObject);
begin
  Memo1.Lines.Clear;
end;

end.

