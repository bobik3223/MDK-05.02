unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TManagaer_tasks }

  TManagaer_tasks = class(TForm)
    bAdd_task: TButton;
    bDel_task: TButton;
    bSave: TButton;
    bLoad: TButton;
    Input_task: TEdit;
    Task: TLabel;
    ListBox1: TListBox;
    procedure bAdd_taskClick(Sender: TObject);
    procedure bDel_taskClick(Sender: TObject);
    procedure bLoadClick(Sender: TObject);
    procedure bSaveClick(Sender: TObject);

  end;

var
  Managaer_tasks: TManagaer_tasks;

implementation

{$R *.lfm}

{ TManagaer_tasks }


procedure TManagaer_tasks.bAdd_taskClick(Sender: TObject);
var
  NextNum: Integer;
begin
  if Input_task.Text <> '' then
  begin
    // Вычисляем следующий порядковый номер
    NextNum := ListBox1.Items.Count + 1;
    // Добавляем строку в формате "1. Текст"
    ListBox1.Items.Add(IntToStr(NextNum) + '. ' + Input_task.Text);
    Input_task.Clear; // Очищаем поле ввода
  end;
end;

procedure TManagaer_tasks.bDel_taskClick(Sender: TObject);
var
  i, PointPos: Integer;
  TaskText: string;
begin
  if ListBox1.ItemIndex <> -1 then
  begin
    // Удаляем выбранную задачу
    ListBox1.Items.Delete(ListBox1.ItemIndex);

    // Проходим по всем оставшимся строкам и обновляем их номера
    for i := 0 to ListBox1.Items.Count - 1 do
    begin
      TaskText := ListBox1.Items[i]; // Получаем текущую строку
      PointPos := Pos('. ', TaskText);
      if PointPos > 0 then
        // Отрезаем всё, что было до точки включительно вместе с пробелом
        Delete(TaskText, 1, PointPos + 1);
      // Записываем строку обратно с НОВЫМ индексом (i + 1)
      ListBox1.Items[i] := IntToStr(i + 1) + '. ' + TaskText;
    end;
  end
  else
    ShowMessage('Выберите задачу для удаления');
end;

procedure TManagaer_tasks.bLoadClick(Sender: TObject);
begin
  if FileExists('tasks.txt') then
  begin
    ListBox1.Items.LoadFromFile('tasks.txt');
  end
  else
    ShowMessage('Файл сохранений (tasks.txt) не найден');
end;

procedure TManagaer_tasks.bSaveClick(Sender: TObject);
begin
  ListBox1.Items.SaveToFile('tasks.txt');
  ShowMessage('Список задач успешно сохранен');
end;

end.

