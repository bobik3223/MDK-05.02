unit Unit4;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TForm4 }

  TForm4 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure Edit2Change(Sender: TObject);
  private

  public

  end;

var
  Form4: TForm4;

implementation

{$R *.lfm}

{ TForm4 }

procedure TForm4.BitBtn1Click(Sender: TObject);
begin
  Close;
end;

procedure TForm4.Button1Click(Sender: TObject);
var a, b, h, x, y: Double;
begin
  a := StrToFloat(Edit1.Text);
  b := StrToFloat(Edit2.Text);
  h := StrToFloat(Edit3.Text);
  Memo1.Lines.Clear;

  x := a;

  while x <= b do
  begin
    y := x * x;

    Memo1.Lines.Add('x = ' + FloatToStrF(x, ffFixed, 8, 2) +
                    ' | y = ' + FloatToStrF(y, ffFixed, 8, 2));

    x := x + h;
  end;
end;

procedure TForm4.Button2Click(Sender: TObject);
begin
  Clear;
end;

procedure TForm4.Edit1Change(Sender: TObject);
begin

end;

procedure TForm4.Edit2Change(Sender: TObject);
begin

end;

end.

