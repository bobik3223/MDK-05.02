unit Unit3;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TForm3 }

  TForm3 = class(TForm)
    BitBtn1: TBitBtn;
    Button1: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Memo1: TMemo;
    procedure BitBtn1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private

  public

  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

{ TForm3 }

procedure TForm3.BitBtn1Click(Sender: TObject);
begin
  Close;
end;

procedure TForm3.Button1Click(Sender: TObject);
var i,t,k,k1:integer;
begin
  k:=strtoint(Edit1.Text); // число
  k1:=strtoint(Edit2.Text); // степень
  i:=1; t:=1;

  while i<=k1 do begin
     t:=t*k;
     i:=i+1;
  end;

  Memo1.Lines.add('Число '+Edit1.Text+' в степени '+Edit2.Text+' равно: '+IntToStr(t));

end;

end.

