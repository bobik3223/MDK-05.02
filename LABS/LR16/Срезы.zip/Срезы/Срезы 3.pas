﻿begin
  var n := ReadInteger('Сколько элементов?');
  var a := ReadArrInteger(n);
  
  var srez := a[1::2];
  write('срез: ');
  srez.Println;
  
  var m := srez.Min;
  writeln('мин: ', m);
  
end.