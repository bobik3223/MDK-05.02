﻿begin
  var m := ReadInteger('Введите размер массива:');
  var a := ReadArrInteger(m);
  writeln('массив: ', a);
  
  var n := ReadInteger('введите n:');

  var i := a.IndexMin;
  
  var result := a[:i] + Arr(n) + a[i:];
  
  writeln('результат: ', result);
end.