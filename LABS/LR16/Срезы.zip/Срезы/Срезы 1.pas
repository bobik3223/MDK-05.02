﻿begin
  var n := ReadInteger('Сколько элементов?');
  var a := ReadArrInteger(n);
  a[::-1].Print;
end.  