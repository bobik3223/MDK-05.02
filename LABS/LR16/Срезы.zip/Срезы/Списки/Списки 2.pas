﻿begin
  var n := ReadInteger('Введите количество элементов в списке:');
  writeln('Введите элементы через пробел:');
  
  var L := Lst(ReadArrInteger(n));
  
  write('список: ');
  L.Println;
  var k := L.IndexMax;
  L.RemoveAt(k);
  write('результат: ');
  Print(L); 
end.