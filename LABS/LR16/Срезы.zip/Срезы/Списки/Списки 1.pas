﻿begin
  var n := ReadInteger('Введите размер массива N:');
  var a := ArrRandomInteger(n, -5, 20);
  
  write('массив:  ');
  println(a);
  
  var L1 := new List<integer>; // Для положительных
  var L2 := new List<integer>; // Для отрицательных
  
  foreach var x in a do
  begin
    if x > 0 then
      L1 += x   
    else if x < 0 then
      L2 += x;  
  end;
  
  // 4. Вывод результатов
  write('L1: ');
  L1.Println; 
  
  write('L2: ');
  L2.Println;
end.