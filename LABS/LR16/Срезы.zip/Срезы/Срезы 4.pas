﻿begin
  var n := ReadInteger('Введите размер массива:');
  var a := ReadArrInteger(n); 
  
  writeln('массив: ', a);
 
  var i := a.IndexMax;  
  var result := a[:i] + a[i+1:];

  writeln('результат: ', result);
end.