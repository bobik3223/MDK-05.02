﻿type
  PNode = ^Node;   { указатель на узел }   
  Node = record    { структура узла }
    word: string[40]; { слово }
    count: integer;   { счетчик повторов слов }
    next: PNode;      { ссылка на следующий }
  end;

var
  Head, p, NewNode, Place: PNode;
  F: Text;
  CurrentWord: string;
  TotalUnique: integer;

//Считывание одного слова из файла 
function TakeWord ( F: Text ) : string;
var c: char;
begin
  Result := ''; { пустая строка }
  c := ' ';     { пробел – чтобы войти в цикл }  
  { пропускаем спецсимволы и пробелы }
  while not eof(f) and (c <= ' ') do 
    read(F, c);  
  { читаем слово }  
  while (c > ' ') do begin
    Result := Result + c;
    if eof(f) then break;
    read(F, c);
  end;
end;

// Функция для создания узла 
function CreateNode(NewWord: string): PNode;
var NewNodeLocal: PNode;
begin
  New(NewNodeLocal);
  NewNodeLocal^.word := NewWord;
  NewNodeLocal^.count := 1;
  NewNodeLocal^.next := nil;
  Result := NewNodeLocal;
end;

{ Поиск в списке }
function Find(Head: PNode; NewWord: string): PNode;
var pp: PNode;
begin
  pp := Head;
  // пока не конец списка и слово в просматриваемом узле не равно искомому
  while (pp <> nil) and (NewWord <> pp^.word) do 
    pp := pp^.next;
  Result := pp;
end;

// Вставка слова в определенное место списка по алфавиту 
function FindPlace(Head: PNode; NewWord: string): PNode;
var pp: PNode;
begin
  pp := Head;
  while (pp <> nil) and (NewWord > pp^.word) do
    pp := pp^.next;
  Result := pp;// слово NewWord в алфавитном порядке находится перед pp^.word
end;

// Добавить узел в начало списка 
procedure AddFirst ( var Head: PNode; NewNode: PNode );
begin
  NewNode^.next := Head;
  Head := NewNode;
end;

// Добавить узел после заданного 
procedure AddAfter(p, NewNode: PNode);
begin
  NewNode^.next := p^.next;
  p^.next := NewNode;
end;

// Добавить узел в конец списка 
procedure AddLast ( var Head: PNode; NewNode: PNode );
var pp: PNode;
begin
  if Head = nil then
    AddFirst ( Head, NewNode ) // добавляем в пустой список
  else begin
    pp := Head;
    while pp^.next <> nil do // поиск последнего узла
      pp := pp^.next;
    AddAfter ( pp, NewNode ); // после узла pp добавляем узел
  end;
end;

// Добавить узел перед заданным 
procedure AddBefore(var Head: PNode; p, NewNode: PNode);
var pp: PNode;
begin
  pp := Head;
  if p = Head then
    AddFirst ( Head, NewNode )  // добавление в начало списка
  else begin
    while (pp <> nil)  and  (pp^.next <> p) do // поиск узла, за которым следует узел p
      pp := pp^.next;
    if pp <> nil then AddAfter ( pp, NewNode ); // добавляем после узла pp
  end;
end;

begin
  Head := nil;
  TotalUnique := 0;

  Assign(F, 'input.txt');
  Rewrite(F);
  Writeln(F, 'тренировка спорт тренировка бег спорт');
  Close(F);

  // 1. Открываем рабочий файл
  Reset(F);

  // 2. Считывание очередного слова
  while not eof(F) do
  begin
    CurrentWord := TakeWord(F);
    if CurrentWord = '' then continue;

    // 3. Поиск слова в списке
    p := Find(Head, CurrentWord);

    if p <> nil then
      // 4. Слово нашлось — увеличиваем счетчик
      p^.count := p^.count + 1
    else
    begin
      // 5. Если в списке искомого слова не существует
      NewNode := CreateNode(CurrentWord);      // создание нового узла
      Place := FindPlace(Head, CurrentWord);   // поиск узла, перед которым добавляем
      AddBefore(Head, Place, NewNode);         // добавление узла
      TotalUnique := TotalUnique + 1;          // для выполнения Задания 1
    end;
  end;

  // 6. Закрываем рабочий файл
  Close(F);

  // 7. Печатаем на экран список слов
  writeln('Алфавитно-частотный словарь:');
  p := Head;
  while p <> nil do
  begin
    writeln(p^.word, ': ', p^.count);
    p := p^.next;
  end;

  // Задание: вывести количество различных слов
  writeln('---------------------------');
  writeln('Количество элементов списка (уникальных слов): ', TotalUnique);
end.