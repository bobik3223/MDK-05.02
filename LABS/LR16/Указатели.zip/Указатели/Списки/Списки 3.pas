﻿program MinMaxInList;
type
  PNode = ^Node;
  Node = record
    data: integer;
    next: PNode;
  end;
var
  Head, NewNode, curr: PNode;
  i, min, max: integer;
begin
  Head := nil;
  randomize;
  writeln('Сгенерированный список:');
  for i := 1 to 10 do begin
    new(NewNode);
    NewNode^.data := random(100);
    write(NewNode^.data, ' ');
    NewNode^.next := Head;
    Head := NewNode;
  end;
  writeln;
  if Head = nil then 
  begin
    writeln('Список пуст!');
    exit;
  end;
  min := Head^.data;
  max := Head^.data;
  curr := Head^.next; 
  while curr <> nil do 
  begin
    if curr^.data < min then min := curr^.data;
    if curr^.data > max then max := curr^.data;
    curr := curr^.next; 
  end;
  writeln('Минимальный элемент: ', min);
  writeln('Максимальный элемент: ', max);
  readln; 
end.