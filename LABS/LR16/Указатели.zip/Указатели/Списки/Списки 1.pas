﻿type
  PNode = ^Node;   { указатель на узел }   
  Node = record    { структура узла }
    word: string[40]; { слово }
    count: integer;   { счетчик повторов слов }
    next: PNode;      { ссылка на следующий }
  end;

var
  Head, p, NewNode, Place: PNode;
  CurrentWord, s: string;
  TotalUnique, pos_space: integer;

function CreateNode(NewWord: string): PNode;
var NodePtr: PNode;
begin
  New(NodePtr);
  NodePtr^.word := NewWord;
  NodePtr^.count := 1;
  NodePtr^.next := nil;
  Result := NodePtr;
end;

function Find(Head: PNode; NewWord: string): PNode;
var pp: PNode;
begin
  pp := Head;
  while (pp <> nil) and (NewWord <> pp^.word) do 
    pp := pp^.next;
  Result := pp;
end;

function FindPlace(Head: PNode; NewWord: string): PNode;
var pp: PNode;
begin
  pp := Head;
  while (pp <> nil) and (NewWord > pp^.word) do
    pp := pp^.next;
  Result := pp;
end;

procedure AddFirst ( var Head: PNode; NewNode: PNode );
begin
  NewNode^.next := Head;
  Head := NewNode;
end;

procedure AddAfter(p, NewNode: PNode);
begin
  NewNode^.next := p^.next;
  p^.next := NewNode;
end;

procedure AddBefore(var Head: PNode; p, NewNode: PNode);
var pp: PNode;
begin
  pp := Head;
  if p = Head then
    AddFirst ( Head, NewNode ) 
  else begin
    while (pp <> nil) and (pp^.next <> p) do 
      pp := pp^.next;
    if pp <> nil then AddAfter ( pp, NewNode ); 
  end;
end;

procedure AddLast ( var Head: PNode; NewNode: PNode );
var pp: PNode;
begin
  if Head = nil then AddFirst ( Head, NewNode ) 
  else begin
    pp := Head;
    while pp^.next <> nil do pp := pp^.next;
    AddAfter ( pp, NewNode ); 
  end;
end;

begin
  Head := nil;
  TotalUnique := 0;

  writeln('Введите предложение целиком:');
  readln(s); 
  s := s + ' '; 

  while length(s) > 0 do
  begin
    pos_space := pos(' ', s);
    if pos_space = 0 then 
      break;
    
    CurrentWord := copy(s, 1, pos_space - 1);
    delete(s, 1, pos_space);

    if CurrentWord <> '' then
    begin
      p := Find(Head, CurrentWord);
      if p <> nil then
        p^.count := p^.count + 1
      else
      begin
        NewNode := CreateNode(CurrentWord);      
        Place := FindPlace(Head, CurrentWord);   
        AddBefore(Head, Place, NewNode);         
        TotalUnique := TotalUnique + 1;
      end;
    end;
  end;

  writeln;
  writeln('Алфавитно-частотный словарь:');
  p := Head;
  while p <> nil do
  begin
    writeln(p^.word, ': ', p^.count);
    p := p^.next;
  end;

  writeln('Количество уникальных слов: ', TotalUnique);
end. 