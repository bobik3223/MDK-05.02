﻿type
  PNode = ^Node;
  Node = record
    data: integer;
    next: PNode;
  end;
procedure Push(var Head: PNode; x: integer);
var NewNode: PNode;
begin
  new(NewNode);
  NewNode^.data := x;
  NewNode^.next := Head;
  Head := NewNode;
end;
function Pop(var Head: PNode): integer;
var temp: PNode;
begin
  if Head = nil then exit;
  Pop := Head^.data;
  temp := Head;
  Head := Head^.next;
  dispose(temp);
end;
var
  f1, f2: text;
  num: integer;
  Stack: PNode;
begin
  Stack := nil;
  assign(f1, 'C:\Users\user\Desktop\4 семестр\МДКЕГ\ЛР16\Указатели\Списки\iiiiinput.txt'); 
  reset(f1);
  while not eof(f1) do begin
    read(f1, num);
    Push(Stack, num);
  end;
  close(f1);
  assign(f2, 'C:\Users\user\Desktop\4 семестр\МДКЕГ\ЛР16\Указатели\Списки\output.txt'); // Файл с обратным порядком
  rewrite(f2);
  while Stack <> nil do
    write(f2, Pop(Stack), ' ');
  close(f2);
  writeln('Файл успешно переписан в обратном порядке.');
end.