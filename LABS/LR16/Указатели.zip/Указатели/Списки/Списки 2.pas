﻿type
  PNode = ^Node;
  Node = record
    data: integer;
    next: PNode;
  end;
var
  Head, NewNode, curr: PNode;
  i: integer;
begin
  Head := nil;
  // Создание списка из 10 элементов
  for i := 1 to 10 do begin
    new(NewNode);
    NewNode^.data := i;
    NewNode^.next := Head;
    Head := NewNode;
  end;
  writeln('Весь список:');
  curr := Head;
  while curr <> nil do begin
    write(curr^.data, ' ');
    curr := curr^.next;
  end;
  writeln(#10, 'Четные элементы:');
  curr := Head;
  while curr <> nil do begin
    if curr^.data mod 2 = 0 then write(curr^.data, ' ');
    curr := curr^.next;
  end;
end.