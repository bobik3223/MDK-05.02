﻿var i: integer;
   i_ptr: ^integer;
begin
  i := 2;
  i_ptr := @i;
  writeln('Адрес n ='  , i_ptr); 
  writeln('n = ', i_ptr^); 
end.