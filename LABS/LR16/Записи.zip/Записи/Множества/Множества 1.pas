﻿var
  n: integer;      // количество лет
  d1: integer;     // последняя цифра
  d2: integer;     // последние две цифры (для исключений)
  goda: set of byte; 
  let: set of byte;

begin
  readln(n);
  
  d1 := n mod 10;   
  d2 := n mod 100;  

  goda := [2, 3, 4];
  let := [11, 12, 13, 14];

  if d2 in let then
    writeln(n, ' лет')
  else if d1 = 1 then
    writeln(n, ' год')
  else if d1 in goda then
    writeln(n, ' года')
  else
    writeln(n, ' лет');
end.