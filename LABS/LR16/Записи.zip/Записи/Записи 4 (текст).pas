﻿type
  toy = record
    name: string;
    price: real;
    age: string;
  end;
var
  shop: array[1..2] of toy;
  f: text;      
  s: string;    
  i: integer;
begin
  with shop[1] do
  begin
    name := 'Динозавр';
    price := 1500;
    age := '6-12 лет';
  end;

  with shop[2] do
  begin
    name := 'Мяч';
    price := 450;
    age := '3+';
  end;

  assign(f, 'toys.txt');
  rewrite(f);
  
  for i := 1 to 2 do
  begin
    writeln(f, 'Товар: ', shop[i].name);
    writeln(f, 'Цена: ', shop[i].price);
    writeln(f, 'Возраст: ', shop[i].age);
    writeln(f); 
  end;
  close(f);
  reset(f);
  writeln('Содержимое файла:');
  
  while not eof(f) do
  begin
    readln(f, s); 
    writeln(s);   
  end;
  close(f);
end.