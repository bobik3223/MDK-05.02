﻿type
  toy = record
    // Для типизированных файлов лучше использовать фиксированную длину строк
    name: string[50];
    price: real;
    age: string[20];
  end;

var
  shop: array[1..2] of toy;
  f: file of toy; // Объявляем типизированный файл
  t_buffer: toy;  // Буферная переменная для чтения из файла
  i: integer;

begin
  with shop[1] do
  begin
    name := 'Динозавр';
    price := 1500;
    age := '6-12 лет';
  end;

  with shop[2] do
  begin
    name := 'Мяч';
    price := 450;
    age := '3+';
  end;

  // Запись в файл 
  Assign(f, 'toys_data.dat');
  Rewrite(f);
  
  for i := 1 to 2 do
    write(f, shop[i]); 
    
  Close(f);
  writeln('Данные успешно записаны в файл.');
  writeln;

  // Считывание и вывод
  Reset(f); 
  writeln('Считывание данных из файла и вывод:');
  
  while not Eof(f) do
  begin
    read(f, t_buffer); 
    with t_buffer do
      writeln('Товар: ', name, ', Цена: ', price, ', Возраст: ', age);
  end;
  
  Close(f);
end.