﻿type
  toy = record
    name: string;
    price: real;
    age: string;
  end;

var
  shop: array[1..2] of toy;
  i: integer;
begin
  with shop[1] do
  begin
    name := 'Динозавр';
    price := 1500;
    age := '6-12 лет';
  end;

  with shop[2] do
  begin
    name := 'Мяч';
    price := 450;
    age := '3+';
  end;

  writeln('Список товаров:');
  for i := 1 to 2 do
  begin
    with shop[i] do
      writeln('Товар: ', name, ', Цена: ', price, ', Возраст: ', age);
  end;
end.