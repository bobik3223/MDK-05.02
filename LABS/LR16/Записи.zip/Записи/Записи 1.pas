﻿type anketa = record
  fio: string;
  birth: string;
  kurs: 1..5;
end;
var student: anketa;

begin
  write('Введите ФИО: ');
  readln(student.fio);
  write('Введите дату рождения: ');
  readln(student.birth);
  write('Введите курс (1-5): ');
  readln(student.kurs);
  
  writeln('Данные из анкеты студента ');
  writeln('Студент: ', student.fio);
  writeln('Дата рождения: ', student.birth);
  writeln('Курс обучения: ', student.kurs);
end.