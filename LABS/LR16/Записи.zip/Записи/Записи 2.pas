﻿type 
  anketa = record
    fio: string;
    birth: string;   
    kurs: 1..5;       
  end;

var 
  students: array[1..2] of anketa; 
  i: integer;

begin
  students[1].fio := 'Иванов И.И.';
  students[1].birth := '01.01.2005';
  students[1].kurs := 1;

  students[2].fio := 'Петров П.П.';
  students[2].birth := '02.02.2006';
  students[2].kurs := 2;

  for i := 1 to 2 do
    writeln(students[i].fio, ' ', students[i].birth, ' ', students[i].kurs);
end.